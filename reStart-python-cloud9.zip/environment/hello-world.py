print("Hello, World GG")

nombre  = 'Manuel Ortiz'
edad 27
instructor = False
estatura = 1.70

nuevaEstaturta = int (estatura)
print(nuevaEstaturta)

print('Hola mi nombre es ' + nombre + )
